﻿#Requires -Version 6.0.1 
"Requires version '6.0.1'"
"Running version $($PSVersionTable.PSVersion)"


<#
#Requires -Version 4.0
'Requires version 4.0'
"Running PowerShell $($PSVersionTable.PSVersion)."

#Requires -Version 5.1.99999.999
'Requires version 5.1.99999.999'
"Running PowerShell $($PSVersionTable.PSVersion)."

#Requires -Version 6.0.0 
'Requires version 6.0.0'
"Running version $($PSVersionTable.PSVersion)"

#Requires -Version 6.0.1 
"Requires version '6.0.1'"
"Running version $($PSVersionTable.PSVersion)"

############

#Requires -Version 6.0.0-beta 
"Requires version '6.0.0-beta'"
"Running version $($PSVersionTable.PSVersion)"

#Requires -Version 6.0.0-beta 
"Requires version '6.0.0-beta'"
"Running version $($PSVersionTable.PSVersion)"

#Requires -Version 6.0.1
'Requires version 6.0.1'
"Running PowerShell $($PSVersionTable.PSVersion)."
#>

